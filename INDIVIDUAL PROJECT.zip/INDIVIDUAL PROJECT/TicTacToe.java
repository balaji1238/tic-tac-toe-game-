/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

import java.util.*;

public class TicTacToe {
    static char[][] board = {{' ', ' ', ' '}, {' ', ' ', ' '}, {' ', ' ', ' '}};
    static char currentPlayer = 'X';

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        displayInstructions();
        while (true) {
            startNewGame();
            playGame(sc);
            System.out.println("Do you want to play again? (yes/no)");
            if (!sc.next().equalsIgnoreCase("yes")) {
                System.out.println("Thanks for playing!");
                break;
            }
        }
        sc.close();
    }

    static void playGame(Scanner sc) {
        int moves = 0;
        while (true) {
            printBoard();
            System.out.println("Player " + currentPlayer + "'s turn. Enter row and column (0-2):");
            int row = sc.nextInt(), col = sc.nextInt();
            if (!isValidMove(row, col)) {
                System.out.println("Invalid move. Try again.");
                continue;
            }
            board[row][col] = currentPlayer;
            moves++;
            if (checkWin(row, col)) {
                printBoard();
                System.out.println("Player " + currentPlayer + " wins!");
                break;
            } else if (moves == 9) {
                printBoard();
                System.out.println("It's a draw!");
                break;
            }
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
        }
    }

    static void printBoard() {
        System.out.println("  0 1 2");
        for (int i = 0; i < 3; i++) {
            System.out.print(i + " ");
            for (int j = 0; j < 3; j++) {
                System.out.print(board[i][j]);
                if (j < 2) System.out.print("|");
            }
            System.out.println();
            if (i < 2) System.out.println("  -----");
        }
    }

    static boolean checkWin(int row, int col) {
        return (board[row][0] == currentPlayer && board[row][1] == currentPlayer && board[row][2] == currentPlayer) ||
               (board[0][col] == currentPlayer && board[1][col] == currentPlayer && board[2][col] == currentPlayer) ||
               (row == col && board[0][0] == currentPlayer && board[1][1] == currentPlayer && board[2][2] == currentPlayer) ||
               (row + col == 2 && board[0][2] == currentPlayer && board[1][1] == currentPlayer && board[2][0] == currentPlayer);
    }

    static boolean isValidMove(int row, int col) {
        if (row < 0 || row > 2 || col < 0 || col > 2 || board[row][col] != ' ') {
            return false;
        }
        return true;
    }

    static void resetBoard() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j] = ' ';
            }
        }
        currentPlayer = 'X';
    }

    static void displayInstructions() {
        System.out.println("Welcome to Tic Tac Toe!");
        System.out.println("Players take turns entering row and column numbers (0-2) to place their mark.");
        System.out.println("The first player to get three marks in a row, column, or diagonal wins.");
        System.out.println("If all 9 spots are filled without a winner, the game ends in a draw.");
        System.out.println("Enter 'yes' at the end to play again or 'no' to quit.");
    }

    static void startNewGame() {
        resetBoard();
        System.out.println("Starting a new game...");
    }
}

